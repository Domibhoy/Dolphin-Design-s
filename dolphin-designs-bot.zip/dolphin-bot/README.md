# Dolphin Designs Bot

Python / discord.py 2.x bot with: Roblox tax calculator, tickets, automod, anti-raid,
orders, giveaways, embed builder, infractions and promotions. Data is stored in `dolphin.db` (SQLite).

## Setup
1. https://discord.com/developers/applications -> New Application -> Bot -> copy the token.
2. Under **Bot -> Privileged Gateway Intents** enable **Server Members** and **Message Content**.
3. Invite with scopes `bot` + `applications.commands` and permissions: Manage Channels, Manage Roles,
   Kick, Ban, Moderate Members, Manage Messages, Send Messages, Embed Links, Attach Files, Read Message History.
   (Put the bot's role ABOVE the staff/rank roles it needs to manage.)
4. `cp .env.example .env`, paste the token (and your server ID as GUILD_ID for instant slash commands).
5. `pip install -r requirements.txt` then `python main.py` (needs Python 3.10+).

## First-time config (in Discord)
- `/setup logs`, `/setup staff-role`, `/setup ticket-category`, `/setup order-category`, `/setup promo-channel`
- `/ticket panel` and `/order panel` in the channels you want the panels
- `/rank add role position` for each rank (1 = lowest), then `/promote` and `/demote`
- `/automod status`, `/antiraid status` to review defaults

## Commands
Tax: `/tax` | Tickets: `/ticket panel|add|remove` | Moderation: `/warn /timeout /untimeout /kick /ban /unban /purge /lock /unlock /infractions /delinfraction`
AutoMod: `/automod toggle|status|warn-threshold|word-add|word-remove|word-list` | Anti-raid: `/antiraid status|toggle|config|lockdown|end`
Orders: `/order panel|status|assign|info|list|close` | Giveaways: `/giveaway start|end|reroll|list`
Embeds: `/embed` | Promotions: `/promote /demote /promotions /rank add|remove|list`

Staff = anyone with Manage Server or the staff role set with `/setup staff-role`.
The DevEx rate in `cogs/roblox.py` (DEVEX_RATE) should be checked against Roblox's current rate.
