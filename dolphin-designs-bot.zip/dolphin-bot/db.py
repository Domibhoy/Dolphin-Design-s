import aiosqlite

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER, key TEXT, value TEXT, PRIMARY KEY (guild_id, key));
CREATE TABLE IF NOT EXISTS infractions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, user_id INTEGER,
    mod_id INTEGER, type TEXT, reason TEXT, created_at INTEGER);
CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, channel_id INTEGER,
    user_id INTEGER, category TEXT, claimed_by INTEGER, status TEXT DEFAULT 'open',
    created_at INTEGER);
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, channel_id INTEGER,
    user_id INTEGER, item TEXT, details TEXT, budget TEXT,
    status TEXT DEFAULT 'Pending', assigned_to INTEGER, created_at INTEGER);
CREATE TABLE IF NOT EXISTS giveaways (
    id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, channel_id INTEGER,
    message_id INTEGER, prize TEXT, winners INTEGER, host_id INTEGER,
    ends_at INTEGER, ended INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS giveaway_entries (
    giveaway_id INTEGER, user_id INTEGER, PRIMARY KEY (giveaway_id, user_id));
CREATE TABLE IF NOT EXISTS ranks (
    guild_id INTEGER, position INTEGER, role_id INTEGER, PRIMARY KEY (guild_id, role_id));
CREATE TABLE IF NOT EXISTS promotions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER, user_id INTEGER,
    mod_id INTEGER, action TEXT, from_role INTEGER, to_role INTEGER,
    reason TEXT, created_at INTEGER);
"""


class DB:
    def __init__(self, path: str):
        self.path = path
        self.conn: aiosqlite.Connection | None = None

    async def connect(self):
        self.conn = await aiosqlite.connect(self.path)
        self.conn.row_factory = aiosqlite.Row
        await self.conn.executescript(SCHEMA)
        await self.conn.commit()

    async def execute(self, query: str, params=()):
        cur = await self.conn.execute(query, params)
        await self.conn.commit()
        return cur.lastrowid

    async def one(self, query: str, params=()):
        cur = await self.conn.execute(query, params)
        return await cur.fetchone()

    async def all(self, query: str, params=()):
        cur = await self.conn.execute(query, params)
        return await cur.fetchall()

    async def get(self, guild_id: int, key: str, default=None):
        row = await self.one("SELECT value FROM settings WHERE guild_id=? AND key=?", (guild_id, key))
        return row["value"] if row else default

    async def set(self, guild_id: int, key: str, value):
        await self.execute(
            "INSERT INTO settings (guild_id, key, value) VALUES (?,?,?) "
            "ON CONFLICT(guild_id, key) DO UPDATE SET value=excluded.value",
            (guild_id, key, str(value)),
        )
