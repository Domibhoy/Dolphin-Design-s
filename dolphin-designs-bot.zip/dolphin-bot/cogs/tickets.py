import asyncio
import time
import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed, is_staff, staff_only, send_log, build_transcript, text_file

MAX_OPEN = 2
CATEGORIES = {
    "support": ("Support", "🛟", "General help and questions"),
    "purchase": ("Purchase / Commission", "🛒", "Buy or commission a design"),
    "other": ("Other", "💬", "Anything else"),
}


class TicketSelect(discord.ui.Select):
    def __init__(self):
        options = [discord.SelectOption(label=v[0], value=k, emoji=v[1], description=v[2])
                   for k, v in CATEGORIES.items()]
        super().__init__(custom_id="dd:ticket:select", placeholder="Open a ticket - choose a category", options=options)

    async def callback(self, interaction: discord.Interaction):
        await interaction.client.get_cog("Tickets").open_ticket(interaction, self.values[0])


class TicketPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(TicketSelect())


class TicketControls(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Claim", emoji="🙋", style=discord.ButtonStyle.success, custom_id="dd:ticket:claim")
    async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
        bot = interaction.client
        if not await is_staff(bot, interaction.user):
            return await interaction.response.send_message("Only staff can claim tickets.", ephemeral=True)
        await bot.db.execute("UPDATE tickets SET claimed_by=? WHERE channel_id=?",
                             (interaction.user.id, interaction.channel.id))
        await interaction.response.send_message(
            embed=make_embed(description=f"🙋 This ticket has been claimed by {interaction.user.mention}."))

    @discord.ui.button(label="Close", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="dd:ticket:close")
    async def close(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.client.get_cog("Tickets").close_ticket(interaction)


class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(TicketPanel())
        self.bot.add_view(TicketControls())

    ticket = app_commands.Group(name="ticket", description="Ticket tools", guild_only=True)

    @ticket.command(name="panel", description="Post the ticket panel in this channel")
    @staff_only()
    async def panel(self, i: discord.Interaction):
        e = make_embed(
            "🎫 Dolphin Designs Support",
            "Need help, want to buy a design or request a commission?\n"
            "Pick a category below and a private ticket will be opened for you.")
        await i.channel.send(embed=e, view=TicketPanel())
        await i.response.send_message("Panel posted.", ephemeral=True)

    @ticket.command(name="add", description="Add a user to this ticket")
    @staff_only()
    async def add(self, i: discord.Interaction, user: discord.Member):
        if not await self.bot.db.one("SELECT 1 FROM tickets WHERE channel_id=?", (i.channel.id,)):
            return await i.response.send_message("This isn't a ticket channel.", ephemeral=True)
        await i.channel.set_permissions(user, view_channel=True, send_messages=True, read_message_history=True)
        await i.response.send_message(f"Added {user.mention} to the ticket.")

    @ticket.command(name="remove", description="Remove a user from this ticket")
    @staff_only()
    async def remove(self, i: discord.Interaction, user: discord.Member):
        if not await self.bot.db.one("SELECT 1 FROM tickets WHERE channel_id=?", (i.channel.id,)):
            return await i.response.send_message("This isn't a ticket channel.", ephemeral=True)
        await i.channel.set_permissions(user, overwrite=None)
        await i.response.send_message(f"Removed {user.mention} from the ticket.")

    async def open_ticket(self, interaction: discord.Interaction, key: str):
        guild, db, user = interaction.guild, self.bot.db, interaction.user
        existing = await db.all("SELECT channel_id FROM tickets WHERE guild_id=? AND user_id=? AND status='open'",
                                (guild.id, user.id))
        if len(existing) >= MAX_OPEN:
            return await interaction.response.send_message(
                f"You already have an open ticket: <#{existing[0]['channel_id']}>", ephemeral=True)
        await interaction.response.defer(ephemeral=True)

        cat_id = await db.get(guild.id, "ticket_category")
        category = guild.get_channel(int(cat_id)) if cat_id else None
        role_id = await db.get(guild.id, "staff_role")
        role = guild.get_role(int(role_id)) if role_id else None

        perms = discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True,
                                            embed_links=True, read_message_history=True)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: perms,
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                                  manage_channels=True, read_message_history=True),
        }
        if role:
            overwrites[role] = perms

        label, emoji, _ = CATEGORIES[key]
        ticket_id = await db.execute(
            "INSERT INTO tickets (guild_id, channel_id, user_id, category, created_at) VALUES (?,?,?,?,?)",
            (guild.id, 0, user.id, key, int(time.time())))
        channel = await guild.create_text_channel(
            f"ticket-{ticket_id:04d}", category=category, overwrites=overwrites,
            topic=f"Ticket #{ticket_id} | {user} | {label}")
        await db.execute("UPDATE tickets SET channel_id=? WHERE id=?", (channel.id, ticket_id))

        e = make_embed(f"{emoji} {label} • Ticket #{ticket_id:04d}",
                       f"Hi {user.mention}, thanks for reaching out!\n"
                       "Please describe what you need and a member of staff will be with you shortly.")
        await channel.send(content=f"{user.mention} {role.mention if role else ''}".strip(),
                           embed=e, view=TicketControls())
        await interaction.followup.send(f"Your ticket is ready: {channel.mention}", ephemeral=True)
        await send_log(self.bot, guild, make_embed(
            "Ticket opened", f"#{ticket_id:04d} • {label}\nBy {user.mention} in {channel.mention}"))

    async def close_ticket(self, interaction: discord.Interaction):
        db = self.bot.db
        row = await db.one("SELECT * FROM tickets WHERE channel_id=?", (interaction.channel.id,))
        if not row:
            return await interaction.response.send_message("This isn't a ticket channel.", ephemeral=True)
        if not (await is_staff(self.bot, interaction.user) or interaction.user.id == row["user_id"]):
            return await interaction.response.send_message("You can't close this ticket.", ephemeral=True)

        await interaction.response.send_message(
            embed=make_embed(description="🔒 Closing this ticket in 5 seconds and saving a transcript…"))
        text = await build_transcript(interaction.channel)
        name = f"transcript-{row['id']:04d}.txt"
        await db.execute("UPDATE tickets SET status='closed' WHERE id=?", (row["id"],))

        log = make_embed("Ticket closed",
                         f"#{row['id']:04d} • Opened by <@{row['user_id']}>\nClosed by {interaction.user.mention}")
        cid = await db.get(interaction.guild.id, "log_channel")
        ch = interaction.guild.get_channel(int(cid)) if cid else None
        if ch:
            try:
                await ch.send(embed=log, file=text_file(text, name))
            except discord.HTTPException:
                pass
        member = interaction.guild.get_member(row["user_id"])
        if member:
            try:
                await member.send("Your Dolphin Designs ticket was closed. Here's the transcript:",
                                  file=text_file(text, name))
            except discord.HTTPException:
                pass
        await asyncio.sleep(5)
        await interaction.channel.delete(reason=f"Ticket closed by {interaction.user}")


async def setup(bot):
    await bot.add_cog(Tickets(bot))
