import time
import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed, staff_only, send_log


class Promotions(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def ladder(self, guild):
        rows = await self.bot.db.all("SELECT position, role_id FROM ranks WHERE guild_id=? ORDER BY position", (guild.id,))
        return [(r["position"], guild.get_role(r["role_id"])) for r in rows if guild.get_role(r["role_id"])]

    @staticmethod
    def current(member, ladder) -> int:
        idx = -1
        for n, (_, role) in enumerate(ladder):
            if role in member.roles:
                idx = n
        return idx

    rank = app_commands.Group(name="rank", description="Staff rank ladder",
                              default_permissions=discord.Permissions(manage_guild=True), guild_only=True)

    @rank.command(name="add", description="Add a role to the ladder (lower position = lower rank)")
    async def rank_add(self, i: discord.Interaction, role: discord.Role, position: app_commands.Range[int, 1, 100]):
        await self.bot.db.execute(
            "INSERT INTO ranks (guild_id, position, role_id) VALUES (?,?,?) "
            "ON CONFLICT(guild_id, role_id) DO UPDATE SET position=excluded.position",
            (i.guild.id, position, role.id))
        await i.response.send_message(f"{role.mention} set at position {position}.", ephemeral=True)

    @rank.command(name="remove", description="Remove a role from the ladder")
    async def rank_remove(self, i: discord.Interaction, role: discord.Role):
        await self.bot.db.execute("DELETE FROM ranks WHERE guild_id=? AND role_id=?", (i.guild.id, role.id))
        await i.response.send_message("Removed from the ladder.", ephemeral=True)

    @rank.command(name="list", description="Show the rank ladder")
    async def rank_list(self, i: discord.Interaction):
        ladder = await self.ladder(i.guild)
        if not ladder:
            return await i.response.send_message("No ranks set. Use `/rank add`.", ephemeral=True)
        text = "\n".join(f"**{p}.** {r.mention}" for p, r in reversed(ladder))
        await i.response.send_message(embed=make_embed("Rank ladder (top → bottom)", text), ephemeral=True)

    async def move(self, i: discord.Interaction, member: discord.Member, reason: str, up: bool):
        ladder = await self.ladder(i.guild)
        if not ladder:
            return await i.response.send_message("No rank ladder configured. Use `/rank add` first.", ephemeral=True)
        idx = self.current(member, ladder)
        new_idx = idx + 1 if up else idx - 1
        if up and new_idx >= len(ladder):
            return await i.response.send_message(f"{member.mention} is already at the top rank.", ephemeral=True)
        if not up and idx < 0:
            return await i.response.send_message(f"{member.mention} has no rank to lose.", ephemeral=True)

        old = ladder[idx][1] if idx >= 0 else None
        new = ladder[new_idx][1] if 0 <= new_idx < len(ladder) else None
        for role in (old, new):
            if role and (role >= i.guild.me.top_role or (i.user.id != i.guild.owner_id and role >= i.user.top_role)):
                return await i.response.send_message(
                    f"I (or you) can't manage {role.mention} - it's too high in the role list.", ephemeral=True)

        if old:
            await member.remove_roles(old, reason=f"{'Promotion' if up else 'Demotion'} by {i.user}")
        if new:
            await member.add_roles(new, reason=f"{'Promotion' if up else 'Demotion'} by {i.user}")

        action = "PROMOTION" if up else "DEMOTION"
        await self.bot.db.execute(
            "INSERT INTO promotions (guild_id, user_id, mod_id, action, from_role, to_role, reason, created_at) VALUES (?,?,?,?,?,?,?,?)",
            (i.guild.id, member.id, i.user.id, action, old.id if old else None, new.id if new else None, reason, int(time.time())))

        e = make_embed(f"{'📈 Promotion' if up else '📉 Demotion'}",
                       f"**Member:** {member.mention}\n**From:** {old.mention if old else 'None'}\n"
                       f"**To:** {new.mention if new else 'None'}\n**Reason:** {reason}\n**By:** {i.user.mention}",
                       color=0x2ECC71 if up else 0xE67E22)
        pid = await self.bot.db.get(i.guild.id, "promo_channel")
        ch = i.guild.get_channel(int(pid)) if pid else None
        if ch:
            await ch.send(content=member.mention, embed=e)
        else:
            await send_log(self.bot, i.guild, e)
        try:
            await member.send(embed=e)
        except discord.HTTPException:
            pass
        await i.response.send_message(embed=e)

    @app_commands.command(name="promote", description="Promote a member up the rank ladder")
    @app_commands.guild_only()
    @staff_only()
    async def promote(self, i: discord.Interaction, member: discord.Member, reason: str = "Great work!"):
        await self.move(i, member, reason, up=True)

    @app_commands.command(name="demote", description="Demote a member down the rank ladder")
    @app_commands.guild_only()
    @staff_only()
    async def demote(self, i: discord.Interaction, member: discord.Member, reason: str):
        await self.move(i, member, reason, up=False)

    @app_commands.command(name="promotions", description="View a member's promotion history")
    @app_commands.guild_only()
    @staff_only()
    async def history(self, i: discord.Interaction, member: discord.Member):
        rows = await self.bot.db.all(
            "SELECT * FROM promotions WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 15", (i.guild.id, member.id))
        if not rows:
            return await i.response.send_message("No promotion history.", ephemeral=True)
        lines = [f"<t:{r['created_at']}:d> **{r['action']}** → "
                 f"{('<@&%d>' % r['to_role']) if r['to_role'] else 'None'} • {r['reason']}" for r in rows]
        await i.response.send_message(embed=make_embed(f"Promotion history • {member}", "\n".join(lines)), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Promotions(bot))
