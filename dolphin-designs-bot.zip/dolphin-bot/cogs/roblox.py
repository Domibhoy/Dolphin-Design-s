import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed

# Roblox keeps 30%, creators receive 70%.
# DevEx rate is USD per Robux - check Roblox's current rate and update if it changes.
DEVEX_RATE = 0.0038


class RobloxTax(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="tax", description="Roblox 30% marketplace tax calculator")
    @app_commands.describe(amount="Robux amount", mode="What does the amount represent?")
    @app_commands.choices(mode=[
        app_commands.Choice(name="I want to RECEIVE this much (what price do I set?)", value="receive"),
        app_commands.Choice(name="I'm SELLING at this price (what do I receive?)", value="price"),
    ])
    async def tax(self, interaction: discord.Interaction,
                  amount: app_commands.Range[int, 1, 1_000_000_000], mode: str = "receive"):
        if mode == "receive":
            price = -(-amount * 10 // 7)          # ceil(amount / 0.7)
            while price * 7 // 10 < amount:
                price += 1
            receive = price * 7 // 10
        else:
            price = amount
            receive = price * 7 // 10
        cut = price - receive

        e = make_embed("Roblox Tax Calculator")
        e.add_field(name="Price to set", value=f"**{price:,}** R$")
        e.add_field(name="You receive (70%)", value=f"**{receive:,}** R$")
        e.add_field(name="Roblox cut (30%)", value=f"{cut:,} R$")
        e.add_field(name="Est. DevEx value", value=f"≈ ${receive * DEVEX_RATE:,.2f} USD", inline=False)
        await interaction.response.send_message(embed=e)


async def setup(bot):
    await bot.add_cog(RobloxTax(bot))
