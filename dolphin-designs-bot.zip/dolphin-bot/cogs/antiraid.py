import time
from collections import defaultdict, deque
import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed, send_log


class AntiRaid(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.joins = defaultdict(deque)   # guild_id -> deque[(monotonic_time, member)]
        self.raid_until = {}              # guild_id -> monotonic time when lockdown ends

    async def cfg(self, gid, key, default):
        return int(await self.bot.db.get(gid, key, default))

    async def punish(self, member: discord.Member, reason: str):
        action = await self.bot.db.get(member.guild.id, "raid_action", "kick")
        try:
            await member.send(f"You were removed from **{member.guild.name}** by anti-raid protection: {reason}.")
        except discord.HTTPException:
            pass
        try:
            if action == "ban":
                await member.ban(reason=f"AntiRaid: {reason}")
            else:
                await member.kick(reason=f"AntiRaid: {reason}")
        except discord.HTTPException:
            pass

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        if member.bot:
            return
        gid, db = member.guild.id, self.bot.db
        if await db.get(gid, "antiraid", "1") == "0":
            return

        min_age = await self.cfg(gid, "raid_min_age", "0")
        if min_age and (discord.utils.utcnow() - member.created_at).days < min_age:
            await self.punish(member, f"account younger than {min_age} days")
            await send_log(self.bot, member.guild, make_embed(
                "AntiRaid • New account removed", f"{member} (`{member.id}`) - account under {min_age} days old."))
            return

        now = time.monotonic()
        if self.raid_until.get(gid, 0) > now:
            await self.punish(member, "server is in raid lockdown")
            return

        dq = self.joins[gid]
        dq.append((now, member))
        window = await self.cfg(gid, "raid_window", "10")
        threshold = await self.cfg(gid, "raid_threshold", "5")
        while dq and now - dq[0][0] > window:
            dq.popleft()

        if len(dq) >= threshold:
            self.raid_until[gid] = now + 15 * 60
            burst = [m for _, m in dq]
            dq.clear()
            for m in burst:
                await self.punish(m, "part of a join raid")
            await send_log(self.bot, member.guild, make_embed(
                "🚨 RAID DETECTED",
                f"{len(burst)} members joined within {window}s. Lockdown active for 15 minutes - "
                f"new joins are being removed. Use `/antiraid end` to lift it early.", color=0xE74C3C))

    antiraid = app_commands.Group(name="antiraid", description="Anti-raid protection",
                                  default_permissions=discord.Permissions(manage_guild=True), guild_only=True)

    @antiraid.command(name="status", description="Show anti-raid settings")
    async def status(self, i: discord.Interaction):
        g, db = i.guild.id, self.bot.db
        on = await db.get(g, "antiraid", "1") == "1"
        locked = self.raid_until.get(g, 0) > time.monotonic()
        e = make_embed("Anti-Raid")
        e.add_field(name="Protection", value="✅ On" if on else "❌ Off")
        e.add_field(name="Lockdown", value="🚨 Active" if locked else "Inactive")
        e.add_field(name="Trigger", value=f"{await self.cfg(g, 'raid_threshold', '5')} joins / "
                                          f"{await self.cfg(g, 'raid_window', '10')}s")
        e.add_field(name="Min account age", value=f"{await self.cfg(g, 'raid_min_age', '0')} days")
        e.add_field(name="Action", value=await db.get(g, "raid_action", "kick"))
        await i.response.send_message(embed=e, ephemeral=True)

    @antiraid.command(name="toggle", description="Enable or disable anti-raid")
    async def toggle(self, i: discord.Interaction, enabled: bool):
        await self.bot.db.set(i.guild.id, "antiraid", "1" if enabled else "0")
        await i.response.send_message(f"Anti-raid is now **{'on' if enabled else 'off'}**.", ephemeral=True)

    @antiraid.command(name="config", description="Tune anti-raid thresholds")
    @app_commands.describe(joins="Joins that trigger a raid", seconds="Within this many seconds",
                           min_account_age_days="Remove accounts younger than this (0 = off)", action="What to do")
    @app_commands.choices(action=[app_commands.Choice(name="Kick", value="kick"),
                                  app_commands.Choice(name="Ban", value="ban")])
    async def config(self, i: discord.Interaction, joins: app_commands.Range[int, 2, 50] | None = None,
                     seconds: app_commands.Range[int, 3, 120] | None = None,
                     min_account_age_days: app_commands.Range[int, 0, 365] | None = None,
                     action: str | None = None):
        db, g = self.bot.db, i.guild.id
        if joins is not None:
            await db.set(g, "raid_threshold", joins)
        if seconds is not None:
            await db.set(g, "raid_window", seconds)
        if min_account_age_days is not None:
            await db.set(g, "raid_min_age", min_account_age_days)
        if action:
            await db.set(g, "raid_action", action)
        await i.response.send_message("Anti-raid settings updated. Use `/antiraid status` to review.", ephemeral=True)

    @antiraid.command(name="lockdown", description="Manually start a 15 minute raid lockdown")
    async def lockdown(self, i: discord.Interaction):
        self.raid_until[i.guild.id] = time.monotonic() + 15 * 60
        await i.response.send_message("🚨 Lockdown active for 15 minutes - new joins will be removed.")

    @antiraid.command(name="end", description="End raid lockdown")
    async def end(self, i: discord.Interaction):
        self.raid_until.pop(i.guild.id, None)
        await i.response.send_message("✅ Lockdown lifted.")


async def setup(bot):
    await bot.add_cog(AntiRaid(bot))
