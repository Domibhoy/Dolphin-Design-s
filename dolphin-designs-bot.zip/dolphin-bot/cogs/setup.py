import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed


class Setup(commands.Cog):
    """Server configuration."""

    def __init__(self, bot):
        self.bot = bot

    grp = app_commands.Group(
        name="setup", description="Configure the Dolphin Designs bot",
        default_permissions=discord.Permissions(manage_guild=True), guild_only=True,
    )

    @grp.command(name="logs", description="Channel for moderation, ticket, order and raid logs")
    async def logs(self, i: discord.Interaction, channel: discord.TextChannel):
        await self.bot.db.set(i.guild.id, "log_channel", channel.id)
        await i.response.send_message(f"Log channel set to {channel.mention}.", ephemeral=True)

    @grp.command(name="staff-role", description="Role that counts as staff (mod/ticket/order powers)")
    async def staff_role(self, i: discord.Interaction, role: discord.Role):
        await self.bot.db.set(i.guild.id, "staff_role", role.id)
        await i.response.send_message(f"Staff role set to {role.mention}.", ephemeral=True)

    @grp.command(name="ticket-category", description="Category where ticket channels are created")
    async def ticket_category(self, i: discord.Interaction, category: discord.CategoryChannel):
        await self.bot.db.set(i.guild.id, "ticket_category", category.id)
        await i.response.send_message(f"Tickets will be created in **{category.name}**.", ephemeral=True)

    @grp.command(name="order-category", description="Category where order channels are created")
    async def order_category(self, i: discord.Interaction, category: discord.CategoryChannel):
        await self.bot.db.set(i.guild.id, "order_category", category.id)
        await i.response.send_message(f"Orders will be created in **{category.name}**.", ephemeral=True)

    @grp.command(name="promo-channel", description="Channel where promotions/demotions are announced")
    async def promo_channel(self, i: discord.Interaction, channel: discord.TextChannel):
        await self.bot.db.set(i.guild.id, "promo_channel", channel.id)
        await i.response.send_message(f"Promotions will be announced in {channel.mention}.", ephemeral=True)

    @grp.command(name="show", description="Show current configuration")
    async def show(self, i: discord.Interaction):
        db, g = self.bot.db, i.guild

        async def fmt(key, kind):
            v = await db.get(g.id, key)
            if not v:
                return "*not set*"
            return {"ch": f"<#{v}>", "role": f"<@&{v}>"}[kind] if kind != "cat" else (
                g.get_channel(int(v)).name if g.get_channel(int(v)) else "*missing*")

        e = make_embed("Dolphin Designs • Configuration")
        e.add_field(name="Logs", value=await fmt("log_channel", "ch"))
        e.add_field(name="Staff role", value=await fmt("staff_role", "role"))
        e.add_field(name="Ticket category", value=await fmt("ticket_category", "cat"))
        e.add_field(name="Order category", value=await fmt("order_category", "cat"))
        e.add_field(name="Promotion channel", value=await fmt("promo_channel", "ch"))
        await i.response.send_message(embed=e, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Setup(bot))
