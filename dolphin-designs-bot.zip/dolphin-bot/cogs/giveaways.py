import random
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
from utils import make_embed, staff_only, parse_duration


def gw_embed(prize, winners, host_id, ends_at, winner_text=None) -> discord.Embed:
    if winner_text is None:
        desc = f"Press **Enter** to join!\n\n**Winners:** {winners}\n**Hosted by:** <@{host_id}>\n**Ends:** <t:{ends_at}:R>"
    else:
        desc = f"**Winner(s):** {winner_text}\n**Hosted by:** <@{host_id}>\n**Ended:** <t:{ends_at}:R>"
    return make_embed(f"🎉 {prize}", desc)


class GiveawayView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Enter", emoji="🎉", style=discord.ButtonStyle.primary, custom_id="dd:gw:enter")
    async def enter(self, interaction: discord.Interaction, button: discord.ui.Button):
        db = interaction.client.db
        g = await db.one("SELECT * FROM giveaways WHERE message_id=?", (interaction.message.id,))
        if not g or g["ended"]:
            return await interaction.response.send_message("This giveaway has ended.", ephemeral=True)
        exists = await db.one("SELECT 1 FROM giveaway_entries WHERE giveaway_id=? AND user_id=?",
                              (g["id"], interaction.user.id))
        if exists:
            await db.execute("DELETE FROM giveaway_entries WHERE giveaway_id=? AND user_id=?", (g["id"], interaction.user.id))
            msg = "You left the giveaway."
        else:
            await db.execute("INSERT INTO giveaway_entries VALUES (?,?)", (g["id"], interaction.user.id))
            msg = "You're in! Good luck 🍀"
        count = (await db.one("SELECT COUNT(*) c FROM giveaway_entries WHERE giveaway_id=?", (g["id"],)))["c"]
        await interaction.response.send_message(f"{msg} ({count} entries)", ephemeral=True)


class Giveaways(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(GiveawayView())
        self.checker.start()

    async def cog_unload(self):
        self.checker.cancel()

    @tasks.loop(seconds=15)
    async def checker(self):
        rows = await self.bot.db.all("SELECT id FROM giveaways WHERE ended=0 AND ends_at<=?", (int(time.time()),))
        for r in rows:
            try:
                await self.finish(r["id"])
            except Exception as exc:
                print(f"Giveaway {r['id']} failed to end: {exc}")

    @checker.before_loop
    async def before_checker(self):
        await self.bot.wait_until_ready()

    async def finish(self, gid: int, reroll: bool = False):
        db = self.bot.db
        row = await db.one("SELECT * FROM giveaways WHERE id=?", (gid,))
        guild = self.bot.get_guild(row["guild_id"])
        channel = guild.get_channel(row["channel_id"]) if guild else None
        entries = [r["user_id"] for r in await db.all("SELECT user_id FROM giveaway_entries WHERE giveaway_id=?", (gid,))]
        valid = [uid for uid in entries if (m := guild.get_member(uid)) and not m.bot] if guild else []
        winners = random.sample(valid, min(row["winners"], len(valid)))
        text = ", ".join(f"<@{w}>" for w in winners) or "No valid entries"
        if not reroll:
            await db.execute("UPDATE giveaways SET ended=1 WHERE id=?", (gid,))
        if channel:
            try:
                msg = await channel.fetch_message(row["message_id"])
                if not reroll:
                    await msg.edit(embed=gw_embed(row["prize"], row["winners"], row["host_id"], int(time.time()), text), view=None)
                await msg.reply(f"🎊 {'New winner(s)' if reroll else 'Congratulations'} {text}! You won **{row['prize']}**."
                                if winners else f"No valid entries for **{row['prize']}**.")
            except discord.HTTPException:
                pass
        return winners

    giveaway = app_commands.Group(name="giveaway", description="Giveaways", guild_only=True)

    @giveaway.command(name="start", description="Start a giveaway in this channel")
    @app_commands.describe(duration="e.g. 30m, 2h, 1d", prize="What's being given away", winners="Number of winners")
    @staff_only()
    async def start(self, i: discord.Interaction, duration: str, prize: str,
                    winners: app_commands.Range[int, 1, 20] = 1):
        delta = parse_duration(duration)
        if not delta:
            return await i.response.send_message("Use a duration like `30m`, `2h` or `1d`.", ephemeral=True)
        ends_at = int(time.time() + delta.total_seconds())
        await i.response.send_message(embed=gw_embed(prize, winners, i.user.id, ends_at), view=GiveawayView())
        msg = await i.original_response()
        await self.bot.db.execute(
            "INSERT INTO giveaways (guild_id, channel_id, message_id, prize, winners, host_id, ends_at) VALUES (?,?,?,?,?,?,?)",
            (i.guild.id, i.channel.id, msg.id, prize, winners, i.user.id, ends_at))

    @giveaway.command(name="end", description="End a giveaway early")
    @staff_only()
    async def end(self, i: discord.Interaction, giveaway_id: int):
        row = await self.bot.db.one("SELECT * FROM giveaways WHERE id=? AND guild_id=?", (giveaway_id, i.guild.id))
        if not row or row["ended"]:
            return await i.response.send_message("No active giveaway with that ID.", ephemeral=True)
        await i.response.send_message("Ending giveaway…", ephemeral=True)
        await self.finish(giveaway_id)

    @giveaway.command(name="reroll", description="Pick new winner(s) for an ended giveaway")
    @staff_only()
    async def reroll(self, i: discord.Interaction, giveaway_id: int):
        row = await self.bot.db.one("SELECT * FROM giveaways WHERE id=? AND guild_id=?", (giveaway_id, i.guild.id))
        if not row or not row["ended"]:
            return await i.response.send_message("That giveaway hasn't ended (or doesn't exist).", ephemeral=True)
        await i.response.send_message("Rerolling…", ephemeral=True)
        await self.finish(giveaway_id, reroll=True)

    @giveaway.command(name="list", description="List active giveaways")
    @staff_only()
    async def list(self, i: discord.Interaction):
        rows = await self.bot.db.all("SELECT * FROM giveaways WHERE guild_id=? AND ended=0", (i.guild.id,))
        if not rows:
            return await i.response.send_message("No active giveaways.", ephemeral=True)
        lines = [f"`ID {r['id']}` **{r['prize']}** • ends <t:{r['ends_at']}:R> • <#{r['channel_id']}>" for r in rows]
        await i.response.send_message(embed=make_embed("Active giveaways", "\n".join(lines)), ephemeral=True)


async def setup(bot):
    await bot.add_cog(Giveaways(bot))
