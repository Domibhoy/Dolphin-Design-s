import json
import re
import time
import datetime as dt
from collections import defaultdict, deque
import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed, staff_only, is_staff, send_log, parse_duration

INVITE_RE = re.compile(r"(discord\.gg|discord(?:app)?\.com/invite)/\w+", re.I)
FEATURES = ["invites", "spam", "mentions", "caps", "badwords"]


class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.recent = defaultdict(lambda: deque(maxlen=10))

    # ---------- helpers ----------
    async def add_infraction(self, guild, user, mod, kind, reason, dm=True) -> int:
        inf_id = await self.bot.db.execute(
            "INSERT INTO infractions (guild_id, user_id, mod_id, type, reason, created_at) VALUES (?,?,?,?,?,?)",
            (guild.id, user.id, mod.id, kind, reason, int(time.time())))
        e = make_embed(f"{kind} • Case #{inf_id}",
                       f"**User:** {user.mention} (`{user.id}`)\n**Moderator:** {mod.mention}\n**Reason:** {reason}")
        await send_log(self.bot, guild, e)
        if dm:
            try:
                await user.send(embed=make_embed(
                    f"You received a {kind.lower()} in {guild.name}", f"**Reason:** {reason}"))
            except discord.HTTPException:
                pass
        return inf_id

    async def check_escalation(self, member: discord.Member):
        threshold = int(await self.bot.db.get(member.guild.id, "warn_threshold", "3"))
        row = await self.bot.db.one(
            "SELECT COUNT(*) c FROM infractions WHERE guild_id=? AND user_id=? AND type='WARN'",
            (member.guild.id, member.id))
        if row["c"] and row["c"] % threshold == 0:
            try:
                await member.timeout(dt.timedelta(hours=1), reason=f"{row['c']} warnings")
                await self.add_infraction(member.guild, member, member.guild.me, "TIMEOUT",
                                          f"Auto-timeout (1h) after reaching {row['c']} warnings")
            except discord.HTTPException:
                pass

    async def guard(self, i: discord.Interaction, target: discord.Member) -> bool:
        me, actor = i.guild.me, i.user
        problem = None
        if target.id == actor.id:
            problem = "You can't do that to yourself."
        elif target.id == i.guild.owner_id or (actor.id != i.guild.owner_id and target.top_role >= actor.top_role):
            problem = "You can't act on someone with an equal or higher role."
        elif target.top_role >= me.top_role:
            problem = "My role is too low to act on that member."
        if problem:
            await i.response.send_message(problem, ephemeral=True)
        return problem is None

    # ---------- commands ----------
    @app_commands.command(name="warn", description="Warn a member")
    @app_commands.guild_only()
    @staff_only()
    async def warn(self, i: discord.Interaction, member: discord.Member, reason: str):
        if not await self.guard(i, member):
            return
        cid = await self.add_infraction(i.guild, member, i.user, "WARN", reason)
        await i.response.send_message(embed=make_embed(f"Warned • Case #{cid}", f"{member.mention}: {reason}"))
        await self.check_escalation(member)

    @app_commands.command(name="timeout", description="Timeout a member (e.g. 10m, 2h, 1d)")
    @app_commands.guild_only()
    @staff_only()
    async def timeout(self, i: discord.Interaction, member: discord.Member, duration: str,
                      reason: str = "No reason provided"):
        delta = parse_duration(duration)
        if not delta or delta > dt.timedelta(days=28):
            return await i.response.send_message("Use a duration like `10m`, `2h` or `1d` (max 28d).", ephemeral=True)
        if not await self.guard(i, member):
            return
        await member.timeout(delta, reason=reason)
        cid = await self.add_infraction(i.guild, member, i.user, "TIMEOUT", f"{reason} ({duration})")
        await i.response.send_message(embed=make_embed(f"Timed out • Case #{cid}", f"{member.mention} for {duration}: {reason}"))

    @app_commands.command(name="untimeout", description="Remove a member's timeout")
    @app_commands.guild_only()
    @staff_only()
    async def untimeout(self, i: discord.Interaction, member: discord.Member):
        await member.timeout(None)
        await i.response.send_message(f"Removed timeout from {member.mention}.")

    @app_commands.command(name="kick", description="Kick a member")
    @app_commands.guild_only()
    @staff_only()
    async def kick(self, i: discord.Interaction, member: discord.Member, reason: str = "No reason provided"):
        if not await self.guard(i, member):
            return
        cid = await self.add_infraction(i.guild, member, i.user, "KICK", reason)
        await member.kick(reason=reason)
        await i.response.send_message(embed=make_embed(f"Kicked • Case #{cid}", f"{member}: {reason}"))

    @app_commands.command(name="ban", description="Ban a user")
    @app_commands.guild_only()
    @staff_only()
    async def ban(self, i: discord.Interaction, user: discord.User, reason: str = "No reason provided"):
        member = i.guild.get_member(user.id)
        if member and not await self.guard(i, member):
            return
        cid = await self.add_infraction(i.guild, user, i.user, "BAN", reason)
        await i.guild.ban(user, reason=reason)
        if not i.response.is_done():
            await i.response.send_message(embed=make_embed(f"Banned • Case #{cid}", f"{user}: {reason}"))

    @app_commands.command(name="unban", description="Unban a user by ID")
    @app_commands.guild_only()
    @staff_only()
    async def unban(self, i: discord.Interaction, user_id: str):
        try:
            await i.guild.unban(discord.Object(int(user_id)))
        except (ValueError, discord.NotFound):
            return await i.response.send_message("That user isn't banned (or the ID is invalid).", ephemeral=True)
        await i.response.send_message(f"Unbanned `{user_id}`.")

    @app_commands.command(name="purge", description="Bulk delete recent messages")
    @app_commands.guild_only()
    @staff_only()
    async def purge(self, i: discord.Interaction, amount: app_commands.Range[int, 1, 100],
                    member: discord.Member | None = None):
        await i.response.defer(ephemeral=True)
        check = (lambda m: m.author.id == member.id) if member else None
        deleted = await i.channel.purge(limit=amount, check=check)
        await i.followup.send(f"Deleted {len(deleted)} messages.", ephemeral=True)

    @app_commands.command(name="infractions", description="View a member's infractions")
    @app_commands.guild_only()
    @staff_only()
    async def infractions(self, i: discord.Interaction, user: discord.User):
        rows = await self.bot.db.all(
            "SELECT * FROM infractions WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 15",
            (i.guild.id, user.id))
        if not rows:
            return await i.response.send_message(f"{user} has a clean record.", ephemeral=True)
        lines = [f"`#{r['id']}` **{r['type']}** • <t:{r['created_at']}:R> • <@{r['mod_id']}>\n└ {r['reason']}" for r in rows]
        await i.response.send_message(embed=make_embed(f"Infractions for {user}", "\n".join(lines)), ephemeral=True)

    @app_commands.command(name="delinfraction", description="Delete an infraction by case number")
    @app_commands.guild_only()
    @staff_only()
    async def delinfraction(self, i: discord.Interaction, case: int):
        row = await self.bot.db.one("SELECT 1 FROM infractions WHERE id=? AND guild_id=?", (case, i.guild.id))
        if not row:
            return await i.response.send_message("Case not found.", ephemeral=True)
        await self.bot.db.execute("DELETE FROM infractions WHERE id=?", (case,))
        await i.response.send_message(f"Deleted case #{case}.", ephemeral=True)

    @app_commands.command(name="lock", description="Lock this channel for @everyone")
    @app_commands.guild_only()
    @staff_only()
    async def lock(self, i: discord.Interaction):
        ow = i.channel.overwrites_for(i.guild.default_role)
        ow.send_messages = False
        await i.channel.set_permissions(i.guild.default_role, overwrite=ow)
        await i.response.send_message("🔒 Channel locked.")

    @app_commands.command(name="unlock", description="Unlock this channel")
    @app_commands.guild_only()
    @staff_only()
    async def unlock(self, i: discord.Interaction):
        ow = i.channel.overwrites_for(i.guild.default_role)
        ow.send_messages = None
        await i.channel.set_permissions(i.guild.default_role, overwrite=ow)
        await i.response.send_message("🔓 Channel unlocked.")

    # ---------- automod config ----------
    automod = app_commands.Group(name="automod", description="Auto-moderation settings",
                                 default_permissions=discord.Permissions(manage_guild=True), guild_only=True)

    @automod.command(name="toggle", description="Turn an automod filter on or off")
    @app_commands.choices(feature=[app_commands.Choice(name=f, value=f) for f in FEATURES])
    async def toggle(self, i: discord.Interaction, feature: str, enabled: bool):
        await self.bot.db.set(i.guild.id, f"automod_{feature}", "1" if enabled else "0")
        await i.response.send_message(f"`{feature}` is now **{'on' if enabled else 'off'}**.", ephemeral=True)

    @automod.command(name="status", description="Show automod filters")
    async def status(self, i: discord.Interaction):
        lines = []
        for f in FEATURES:
            on = await self.bot.db.get(i.guild.id, f"automod_{f}", "1") == "1"
            lines.append(f"{'✅' if on else '❌'} {f}")
        thr = await self.bot.db.get(i.guild.id, "warn_threshold", "3")
        lines.append(f"\nAuto-timeout every **{thr}** warnings.")
        await i.response.send_message(embed=make_embed("AutoMod", "\n".join(lines)), ephemeral=True)

    @automod.command(name="warn-threshold", description="Warnings before an automatic 1h timeout")
    async def warn_threshold(self, i: discord.Interaction, count: app_commands.Range[int, 2, 20]):
        await self.bot.db.set(i.guild.id, "warn_threshold", count)
        await i.response.send_message(f"Members are timed out every {count} warnings.", ephemeral=True)

    async def _words(self, guild_id):
        return json.loads(await self.bot.db.get(guild_id, "badwords", "[]"))

    @automod.command(name="word-add", description="Add a blocked word")
    async def word_add(self, i: discord.Interaction, word: str):
        words = await self._words(i.guild.id)
        if word.lower() not in words:
            words.append(word.lower())
        await self.bot.db.set(i.guild.id, "badwords", json.dumps(words))
        await i.response.send_message("Added.", ephemeral=True)

    @automod.command(name="word-remove", description="Remove a blocked word")
    async def word_remove(self, i: discord.Interaction, word: str):
        words = [w for w in await self._words(i.guild.id) if w != word.lower()]
        await self.bot.db.set(i.guild.id, "badwords", json.dumps(words))
        await i.response.send_message("Removed.", ephemeral=True)

    @automod.command(name="word-list", description="List blocked words")
    async def word_list(self, i: discord.Interaction):
        words = await self._words(i.guild.id)
        await i.response.send_message(", ".join(f"||{w}||" for w in words) or "No blocked words.", ephemeral=True)

    # ---------- automod listener ----------
    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild or not isinstance(message.author, discord.Member):
            return
        if await is_staff(self.bot, message.author):
            return
        db, gid, content = self.bot.db, message.guild.id, message.content

        async def on(f):
            return await db.get(gid, f"automod_{f}", "1") == "1"

        reason, timeout = None, None
        key = (gid, message.author.id)
        now = time.monotonic()
        self.recent[key].append(now)

        if await on("invites") and INVITE_RE.search(content):
            reason = "Posting invite links"
        elif await on("mentions") and len(message.mentions) + len(message.role_mentions) >= 5:
            reason = "Mass mentioning"
        elif await on("spam") and sum(1 for t in self.recent[key] if now - t <= 5) >= 6:
            reason, timeout = "Spamming", dt.timedelta(minutes=5)
            self.recent[key].clear()
        elif await on("badwords"):
            low = content.lower()
            if any(re.search(rf"\b{re.escape(w)}\b", low) for w in await self._words(gid)):
                reason = "Blocked word"
        if not reason and await on("caps") and len(content) >= 15:
            letters = [c for c in content if c.isalpha()]
            if letters and sum(c.isupper() for c in letters) / len(letters) > 0.7:
                reason = "Excessive caps"
        if not reason:
            return

        try:
            await message.delete()
        except discord.HTTPException:
            pass
        await message.channel.send(f"{message.author.mention} ⚠️ AutoMod: {reason}.", delete_after=6)
        await self.add_infraction(message.guild, message.author, message.guild.me, "WARN", f"[AutoMod] {reason}")
        if timeout:
            try:
                await message.author.timeout(timeout, reason=f"AutoMod: {reason}")
            except discord.HTTPException:
                pass
        await self.check_escalation(message.author)


async def setup(bot):
    await bot.add_cog(Moderation(bot))
