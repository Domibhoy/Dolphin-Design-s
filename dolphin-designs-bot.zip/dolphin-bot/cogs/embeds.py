import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed, staff_only, BRAND


class EmbedModal(discord.ui.Modal, title="Create embed"):
    e_title = discord.ui.TextInput(label="Title", required=False, max_length=256)
    description = discord.ui.TextInput(label="Description", style=discord.TextStyle.paragraph,
                                       required=False, max_length=4000)
    color = discord.ui.TextInput(label="Colour (hex, e.g. #2b8cff)", required=False, max_length=7)
    image = discord.ui.TextInput(label="Image URL", required=False, max_length=500)
    footer = discord.ui.TextInput(label="Footer", required=False, max_length=200)

    def __init__(self, channel: discord.abc.Messageable):
        super().__init__()
        self.channel = channel

    async def on_submit(self, interaction: discord.Interaction):
        if not (self.e_title.value or self.description.value):
            return await interaction.response.send_message("Add at least a title or description.", ephemeral=True)
        try:
            color = discord.Color.from_str(self.color.value) if self.color.value else discord.Color(BRAND)
        except ValueError:
            color = discord.Color(BRAND)
        e = discord.Embed(title=self.e_title.value or None, description=self.description.value or None, color=color)
        if self.image.value.startswith("http"):
            e.set_image(url=self.image.value)
        e.set_footer(text=self.footer.value or "Dolphin Designs")
        try:
            await self.channel.send(embed=e)
        except discord.HTTPException:
            return await interaction.response.send_message("I couldn't post there - check my permissions.", ephemeral=True)
        await interaction.response.send_message("Embed sent!", ephemeral=True)


class Embeds(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="embed", description="Build and send a custom embed")
    @app_commands.guild_only()
    @staff_only()
    async def embed(self, i: discord.Interaction, channel: discord.TextChannel | None = None):
        await i.response.send_modal(EmbedModal(channel or i.channel))


async def setup(bot):
    await bot.add_cog(Embeds(bot))
