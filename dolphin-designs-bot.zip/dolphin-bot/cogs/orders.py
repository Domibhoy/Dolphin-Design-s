import time
import discord
from discord import app_commands
from discord.ext import commands
from utils import make_embed, is_staff, staff_only, send_log, build_transcript, text_file

STATUSES = {
    "Pending": "🕐", "In Progress": "🛠️", "Awaiting Payment": "💳",
    "Awaiting Feedback": "💬", "Completed": "✅", "Cancelled": "❌",
}


def order_embed(row) -> discord.Embed:
    e = make_embed(f"📦 Order #{row['id']:04d}")
    e.add_field(name="Customer", value=f"<@{row['user_id']}>")
    e.add_field(name="Status", value=f"{STATUSES.get(row['status'], '')} {row['status']}")
    e.add_field(name="Assigned to", value=f"<@{row['assigned_to']}>" if row["assigned_to"] else "Unassigned")
    e.add_field(name="Item", value=row["item"], inline=False)
    e.add_field(name="Details", value=row["details"], inline=False)
    e.add_field(name="Budget", value=row["budget"] or "Not specified")
    return e


class OrderModal(discord.ui.Modal, title="Place an order"):
    item = discord.ui.TextInput(label="What would you like?", placeholder="Logo, banner, UI pack…", max_length=100)
    details = discord.ui.TextInput(label="Details", style=discord.TextStyle.paragraph,
                                   placeholder="Colours, style, references, deadline…", max_length=1000)
    budget = discord.ui.TextInput(label="Budget", placeholder="e.g. 2,000 R$ / £10", max_length=50, required=False)

    async def on_submit(self, interaction: discord.Interaction):
        await interaction.client.get_cog("Orders").create_order(
            interaction, self.item.value, self.details.value, self.budget.value)


class OrderPanel(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Place an order", emoji="🛒", style=discord.ButtonStyle.primary, custom_id="dd:order:new")
    async def new(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(OrderModal())


class Orders(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def cog_load(self):
        self.bot.add_view(OrderPanel())

    order = app_commands.Group(name="order", description="Order system", guild_only=True)

    @order.command(name="panel", description="Post the order panel in this channel")
    @staff_only()
    async def panel(self, i: discord.Interaction):
        e = make_embed("🛒 Order a Design",
                       "Ready to get started? Press the button, fill in the form and we'll open a private "
                       "order channel for you.")
        await i.channel.send(embed=e, view=OrderPanel())
        await i.response.send_message("Panel posted.", ephemeral=True)

    async def create_order(self, interaction, item, details, budget):
        guild, db, user = interaction.guild, self.bot.db, interaction.user
        await interaction.response.defer(ephemeral=True)
        cat_id = await db.get(guild.id, "order_category")
        category = guild.get_channel(int(cat_id)) if cat_id else None
        role_id = await db.get(guild.id, "staff_role")
        role = guild.get_role(int(role_id)) if role_id else None

        perms = discord.PermissionOverwrite(view_channel=True, send_messages=True, attach_files=True,
                                            embed_links=True, read_message_history=True)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: perms,
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True,
                                                  manage_channels=True, read_message_history=True),
        }
        if role:
            overwrites[role] = perms

        order_id = await db.execute(
            "INSERT INTO orders (guild_id, channel_id, user_id, item, details, budget, created_at) VALUES (?,?,?,?,?,?,?)",
            (guild.id, 0, user.id, item, details, budget or None, int(time.time())))
        channel = await guild.create_text_channel(f"order-{order_id:04d}", category=category, overwrites=overwrites,
                                                  topic=f"Order #{order_id} | {user}")
        await db.execute("UPDATE orders SET channel_id=? WHERE id=?", (channel.id, order_id))
        row = await db.one("SELECT * FROM orders WHERE id=?", (order_id,))
        await channel.send(content=f"{user.mention} {role.mention if role else ''}".strip(), embed=order_embed(row))
        await channel.send("Thanks for your order! A designer will review it and update you here shortly.")
        await interaction.followup.send(f"Order placed: {channel.mention}", ephemeral=True)
        await send_log(self.bot, guild, make_embed("New order", f"#{order_id:04d} by {user.mention}\n**{item}**"))

    async def get_order(self, i, order_id):
        row = await self.bot.db.one("SELECT * FROM orders WHERE id=? AND guild_id=?", (order_id, i.guild.id))
        if not row:
            await i.response.send_message("Order not found.", ephemeral=True)
        return row

    @order.command(name="status", description="Update an order's status")
    @app_commands.choices(status=[app_commands.Choice(name=s, value=s) for s in STATUSES])
    @staff_only()
    async def status(self, i: discord.Interaction, order_id: int, status: str, note: str | None = None):
        row = await self.get_order(i, order_id)
        if not row:
            return
        await self.bot.db.execute("UPDATE orders SET status=? WHERE id=?", (status, order_id))
        e = make_embed(f"{STATUSES[status]} Order #{order_id:04d} → {status}", note)
        channel = i.guild.get_channel(row["channel_id"])
        if channel:
            await channel.send(content=f"<@{row['user_id']}>", embed=e)
        member = i.guild.get_member(row["user_id"])
        if member:
            try:
                await member.send(embed=e)
            except discord.HTTPException:
                pass
        await send_log(self.bot, i.guild, e)
        await i.response.send_message("Status updated.", ephemeral=True)

    @order.command(name="assign", description="Assign an order to a designer")
    @staff_only()
    async def assign(self, i: discord.Interaction, order_id: int, designer: discord.Member):
        row = await self.get_order(i, order_id)
        if not row:
            return
        await self.bot.db.execute("UPDATE orders SET assigned_to=? WHERE id=?", (designer.id, order_id))
        channel = i.guild.get_channel(row["channel_id"])
        if channel:
            await channel.send(embed=make_embed(description=f"🎨 {designer.mention} is now handling this order."))
        await i.response.send_message("Assigned.", ephemeral=True)

    @order.command(name="info", description="Show an order")
    async def info(self, i: discord.Interaction, order_id: int):
        row = await self.get_order(i, order_id)
        if not row:
            return
        if row["user_id"] != i.user.id and not await is_staff(self.bot, i.user):
            return await i.response.send_message("That's not your order.", ephemeral=True)
        await i.response.send_message(embed=order_embed(row), ephemeral=True)

    @order.command(name="list", description="List your orders (staff: all open orders)")
    async def list(self, i: discord.Interaction):
        if await is_staff(self.bot, i.user):
            rows = await self.bot.db.all(
                "SELECT * FROM orders WHERE guild_id=? AND status NOT IN ('Completed','Cancelled') ORDER BY id DESC LIMIT 20",
                (i.guild.id,))
            title = "Open orders"
        else:
            rows = await self.bot.db.all(
                "SELECT * FROM orders WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 20", (i.guild.id, i.user.id))
            title = "Your orders"
        if not rows:
            return await i.response.send_message("No orders found.", ephemeral=True)
        lines = [f"`#{r['id']:04d}` {STATUSES.get(r['status'], '')} **{r['status']}** • {r['item']} • <@{r['user_id']}>"
                 for r in rows]
        await i.response.send_message(embed=make_embed(title, "\n".join(lines)), ephemeral=True)

    @order.command(name="close", description="Save a transcript and delete an order channel")
    @staff_only()
    async def close(self, i: discord.Interaction, order_id: int):
        row = await self.get_order(i, order_id)
        if not row:
            return
        channel = i.guild.get_channel(row["channel_id"])
        if not channel:
            return await i.response.send_message("The order channel no longer exists.", ephemeral=True)
        await i.response.send_message("Saving transcript and closing the channel…", ephemeral=True)
        text = await build_transcript(channel)
        cid = await self.bot.db.get(i.guild.id, "log_channel")
        log = i.guild.get_channel(int(cid)) if cid else None
        if log:
            await log.send(embed=make_embed("Order channel closed", f"Order #{order_id:04d} • {row['item']}"),
                           file=text_file(text, f"order-{order_id:04d}.txt"))
        await channel.delete(reason=f"Order closed by {i.user}")


async def setup(bot):
    await bot.add_cog(Orders(bot))
