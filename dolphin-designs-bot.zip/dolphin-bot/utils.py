import io
import re
import datetime as dt
import discord
from discord import app_commands

BRAND = 0x2B8CFF
FOOTER = "Dolphin Designs"


def make_embed(title=None, description=None, color=BRAND, **kw) -> discord.Embed:
    e = discord.Embed(title=title, description=description, color=color, **kw)
    e.set_footer(text=FOOTER)
    e.timestamp = discord.utils.utcnow()
    return e


_DUR = re.compile(r"(\d+)\s*([smhdw])", re.I)
_UNITS = {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}


def parse_duration(text: str) -> dt.timedelta | None:
    """'10m', '2h', '1d12h' -> timedelta (None if unparseable)."""
    total = sum(int(n) * _UNITS[u.lower()] for n, u in _DUR.findall(text or ""))
    return dt.timedelta(seconds=total) if total else None


async def is_staff(bot, member: discord.Member) -> bool:
    if member.guild_permissions.manage_guild:
        return True
    rid = await bot.db.get(member.guild.id, "staff_role")
    return bool(rid and member.get_role(int(rid)))


def staff_only():
    async def predicate(interaction: discord.Interaction) -> bool:
        if isinstance(interaction.user, discord.Member) and await is_staff(interaction.client, interaction.user):
            return True
        raise app_commands.CheckFailure("You need to be staff to use this.")
    return app_commands.check(predicate)


async def send_log(bot, guild: discord.Guild, embed: discord.Embed):
    cid = await bot.db.get(guild.id, "log_channel")
    channel = guild.get_channel(int(cid)) if cid else None
    if channel:
        try:
            await channel.send(embed=embed)
        except discord.HTTPException:
            pass


async def build_transcript(channel: discord.TextChannel) -> str:
    lines = []
    async for m in channel.history(limit=None, oldest_first=True):
        ts = m.created_at.strftime("%Y-%m-%d %H:%M")
        content = m.clean_content
        if m.attachments:
            content += " " + " ".join(a.url for a in m.attachments)
        if m.embeds and not content:
            content = "[embed]"
        lines.append(f"[{ts}] {m.author}: {content}")
    return "\n".join(lines) or "(empty)"


def text_file(text: str, name: str) -> discord.File:
    return discord.File(io.BytesIO(text.encode("utf-8")), filename=name)
