import os
import traceback
import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv
from db import DB

load_dotenv()

EXTENSIONS = [
    "cogs.setup", "cogs.roblox", "cogs.tickets", "cogs.moderation",
    "cogs.antiraid", "cogs.orders", "cogs.giveaways", "cogs.embeds", "cogs.promotions",
]


class DolphinBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.members = True          # needed for antiraid + promotions
        intents.message_content = True  # needed for automod
        super().__init__(command_prefix=commands.when_mentioned, intents=intents, help_command=None)
        self.db = DB("dolphin.db")

    async def setup_hook(self):
        await self.db.connect()
        for ext in EXTENSIONS:
            await self.load_extension(ext)
        guild_id = os.getenv("GUILD_ID")
        if guild_id:
            guild = discord.Object(int(guild_id))
            self.tree.copy_global_to(guild=guild)
            await self.tree.sync(guild=guild)
        else:
            await self.tree.sync()

    async def on_ready(self):
        print(f"Logged in as {self.user} ({self.user.id})")
        await self.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name="Dolphin Designs"))


bot = DolphinBot()


@bot.tree.error
async def on_app_command_error(interaction: discord.Interaction, error: app_commands.AppCommandError):
    if isinstance(error, app_commands.CheckFailure):
        msg = str(error) or "You can't use this command."
    else:
        traceback.print_exception(type(error), error, error.__traceback__)
        msg = "Something went wrong running that command."
    if interaction.response.is_done():
        await interaction.followup.send(msg, ephemeral=True)
    else:
        await interaction.response.send_message(msg, ephemeral=True)


if __name__ == "__main__":
    token = os.getenv("DISCORD_TOKEN")
    if not token:
        raise SystemExit("Set DISCORD_TOKEN in your .env file.")
    bot.run(token)
